

import java.io.IOException;
import java.util.Date;
import java.util.StringTokenizer;
import org.apache.hadoop.io.IntWritable;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper4 extends Mapper<key,value,Text,DoubleWritable> {
	
	public void map(key inpK, value inpV, Context c) throws IOException, InterruptedException{
	
		int usermonth = c.getConfiguration().getInt("Month",5);
		double amt = inpV.getAmt();
		
		Text m=inpV.getdate();
		String m1=m.toString();
		String mon=m1.split("-")[0];
		int data=Integer.parseInt(mon);
	
		if(usermonth==data)
			c.write(new Text(mon), new DoubleWritable(amt));
		
		
		
		}
		
	}

