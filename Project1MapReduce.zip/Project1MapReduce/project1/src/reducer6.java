import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class reducer6 extends Reducer<DoubleWritable, Text, Text, Text> {
public void reduce(DoubleWritable k,Text v,org.apache.hadoop.mapreduce.Mapper.Context c) throws IOException, InterruptedException
{
	c.write(new Text(k.toString()), new Text(v));
}
}
