import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper6 extends Mapper<LongWritable, Text, DoubleWritable, Text> {

	public void map(LongWritable k,Text val,Context c) throws IOException, InterruptedException{
		
		String value=val.toString();
		String eachval[]=value.split(",");
		
		double amt=Double.parseDouble(eachval[3]);

c.write(new DoubleWritable(amt), new Text(val));



		
	}
}
