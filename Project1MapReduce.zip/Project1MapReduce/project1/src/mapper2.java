
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper2 extends Mapper<key, value, Text, IntWritable>{
	public void map(key inpk, value inpv, Context c) throws IOException, InterruptedException{
		int minamt = c.getConfiguration().getInt("Lower", 175);
		int maxamt = c.getConfiguration().getInt("Upper", 200);
		Double amt = inpv.getAmt();
 	   if(amt>minamt && amt<maxamt)
 	   {
 		    c.write(new Text("dummy"),new IntWritable(1));
 	   }
    }
}