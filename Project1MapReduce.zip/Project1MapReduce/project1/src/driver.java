

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;

import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class driver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException, URISyntaxException {
Scanner src = new Scanner(System.in);
try{
		System.out.println("Enter your choice:--");
		System.out.println("1-->Find userid whose purchase amount should be greater than given value");
		System.out.println("2-->To Count all transaction between the given amount");
		System.out.println("3-->Calculate sum and count of transaction of each user id");
		System.out.println("4-->Calculate total sales amt for each Month");
		System.out.println("5-->To place total sales of each month in different files");
		System.out.println("6-->Sort the whole file on the basis of amt.");
		System.out.println("7-->Find the name of top 3 spenders");
		System.out.println("8-->Find the name of user who has spend the maximum amount");
		System.out.println("9-->Find the user who has spend the max amount in July month");
		int choice=src.nextInt();

		switch(choice){
		case 1:
		Configuration conf1 = new Configuration();
		System.out.println("Enter the Amount---");
		int amt = src.nextInt();
		conf1.setInt("Amount", amt);
	if(amt>=1){
		Job j1 = new Job(conf1, "Output");
		FileSystem hdfs1 = FileSystem.get(conf1);
		j1.setJarByClass(driver.class);
		j1.setMapperClass(mapper1.class);
		j1.setNumReduceTasks(0);
		j1.setMapOutputKeyClass(Text.class);
		j1.setMapOutputValueClass(DoubleWritable.class);
		j1.setInputFormatClass(inputformat.class);
		
		
		
		FileInputFormat.addInputPath(j1, new Path(args[0]));
		FileOutputFormat.setOutputPath(j1, new Path (args[1]));
		
		Path newpath1 = new Path(args[1]);
		if(hdfs1.exists(newpath1)){
			hdfs1.delete(newpath1,true);
		}
		Path localfilepath1 = new Path("/home/hduser/InputFormat_Trans1");
		if(j1.waitForCompletion(true)){
			hdfs1.copyToLocalFile(newpath1, localfilepath1);
		}
			
		
		System.exit(j1.waitForCompletion(true)?0:1);
	}
	else
	{
		System.out.println("Pls type minumum value from 1");
	}
		break;
		case 2:
			Configuration conf2 = new Configuration();
			System.out.println("Enter the Min amount");
			int lamt = src.nextInt();
			System.out.println("Enter the Max amount");
			int uamt = src.nextInt();
			if(uamt>=lamt){
			conf2.setInt("Lower", lamt);
			conf2.setInt("Upper", uamt);
			Job j2 = new Job(conf2, "Output");
			FileSystem hdfs2 = FileSystem.get(conf2);
			j2.setJarByClass(driver.class);
		
			j2.setMapperClass(mapper2.class);
			j2.setReducerClass(reducer2.class);
			j2.setNumReduceTasks(1);
			j2.setMapOutputKeyClass(Text.class);
			j2.setMapOutputValueClass(IntWritable.class);
			j2.setInputFormatClass(inputformat.class);
			
			FileInputFormat.addInputPath(j2, new Path(args[0]));
			FileOutputFormat.setOutputPath(j2, new Path (args[1]));
			
			Path newpath2 = new Path(args[1]);
			if(hdfs2.exists(newpath2)){
				hdfs2.delete(newpath2,true);
			}
			Path localfilepath2 = new Path("/home/hduser/InputFormat_Trans2");
			if(j2.waitForCompletion(true)){
				hdfs2.copyToLocalFile(newpath2, localfilepath2);
			}
			
			System.exit(j2.waitForCompletion(true)?0:1);}
			else
			{
				System.out.println("Max amount should be greater than minimum anount");
			}
			break;
		case 3:
			Configuration conf3 = new Configuration();
			System.out.println("Enter the user id");
			int uid = src.nextInt();
			if((uid>=4000000)&&(uid<=4999999)){
			conf3.setInt("User id", uid);
			Job j3 = new Job(conf3, "Output");
			FileSystem hdfs3 = FileSystem.get(conf3);
			j3.setJarByClass(driver.class);
			j3.setMapperClass(mapper3.class);
			j3.setReducerClass(reducer3.class);
			j3.setNumReduceTasks(1);
			j3.setMapOutputKeyClass(Text.class);
			j3.setMapOutputValueClass(DoubleWritable.class);
			j3.setInputFormatClass(inputformat.class);
			
			FileInputFormat.addInputPath(j3, new Path(args[0]));
			FileOutputFormat.setOutputPath(j3, new Path (args[1]));
			
			Path newpath3 = new Path(args[1]);
			if(hdfs3.exists(newpath3)){
				hdfs3.delete(newpath3,true);
			}
			Path localfilepath3 = new Path("/home/hduser/InputFormat_Trans3");
			if(j3.waitForCompletion(true)){
				hdfs3.copyToLocalFile(newpath3, localfilepath3);
			}
			
			System.exit(j3.waitForCompletion(true)?0:1);}
			else
			{
				System.out.println("userid is not valid");
			}
			break;
		case 4:			
			Configuration conf4 = new Configuration();
			System.out.println("Enter the Month");
			int month;
			month=src.nextInt();
				if((month>12)||(month<0)){
					System.out.println("Please Enter a Valid month(1-12)");
				}
				else{
				
			conf4.setInt("Month",month);
			Job j4 = new Job(conf4, "Output");
			FileSystem hdfs4 = FileSystem.get(conf4);
			j4.setJarByClass(driver.class);
	     	j4.setMapperClass(mapper4.class);
	     	j4.setReducerClass(reducer4.class);
	     	j4.setNumReduceTasks(1);
	     	j4.setInputFormatClass(inputformat.class);
	     	j4.setMapOutputKeyClass(Text.class);
			j4.setMapOutputValueClass(DoubleWritable.class);
	     	FileInputFormat.addInputPath(j4, new Path(args[0]));
	     	FileOutputFormat.setOutputPath(j4, new Path(args[1]));
	     	System.exit(j4.waitForCompletion(true)?0:1);
				}
	     	break;
	     	
		case 5:
			Configuration c = new Configuration();
			Job j=new Job(c,"first program");
			j.setJarByClass(driver.class);
			j.setMapperClass(mapper5.class);
			j.setReducerClass(reducer5.class);
			j.setPartitionerClass(part5.class);
			j.setNumReduceTasks(12);
			j.setMapOutputKeyClass(IntWritable.class);
			j.setMapOutputValueClass(Text.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path(args[1]));
			System.exit(j.waitForCompletion(true)?0:1);
	     	
		case 6:
			
			Configuration c6 = new Configuration();
			Job j6=new Job(c6,"first program");
			j6.setJarByClass(driver.class);
			j6.setMapperClass(mapper6.class);
			j6.setReducerClass(reducer6.class);
			
			j6.setNumReduceTasks(1);
			j6.setMapOutputKeyClass(DoubleWritable.class);
			j6.setMapOutputValueClass(Text.class);
			FileInputFormat.addInputPath(j6, new Path(args[0]));
			FileOutputFormat.setOutputPath(j6, new Path(args[1]));
			System.exit(j6.waitForCompletion(true)?0:1);
	     	
			break;
		case 7:
			Configuration conf7 = new Configuration();
			Job j7 = new Job(conf7,"Log 3");
			j7.setJarByClass(driver.class);
			j7.setMapperClass(mapper7.class);	
			j7.setCombinerClass(combiner7.class);
		j7.setReducerClass(reducer7.class);
		j7.setNumReduceTasks(1);
		j7.setMapOutputKeyClass(Text.class);
			j7.setMapOutputValueClass(Text.class);			
			FileInputFormat.addInputPath(j7,new Path(args[0]));
			FileOutputFormat.setOutputPath(j7, new Path(args[1]));			

			DistributedCache.addCacheFile(new URI("/cus.dat"),j7.getConfiguration());


			System.exit(j7.waitForCompletion(true)?0:1);
			
			
			break;
		case 8:
			Configuration conf8 = new Configuration();
		Job j8 = new Job(conf8,"Log 3");
		j8.setJarByClass(driver.class);
		j8.setMapperClass(mapper8.class);	
		j8.setCombinerClass(combainer8.class);
	j8.setReducerClass(reducer8.class);
	j8.setNumReduceTasks(1);
	j8.setMapOutputKeyClass(Text.class);
		j8.setMapOutputValueClass(Text.class);			
		FileInputFormat.addInputPath(j8,new Path(args[0]));
		FileOutputFormat.setOutputPath(j8, new Path(args[1]));			

		DistributedCache.addCacheFile(new URI("/cus.dat"),j8.getConfiguration());


		System.exit(j8.waitForCompletion(true)?0:1);
		
		
		break;
			
		case 9:
			Configuration conf9 = new Configuration();
		Job j9 = new Job(conf9,"Log 3");
		j9.setJarByClass(driver.class);
		j9.setMapperClass(mapper9.class);	
		j9.setCombinerClass(combiner9.class);
	j9.setReducerClass(reducer9.class);
	j9.setNumReduceTasks(1);
	j9.setMapOutputKeyClass(Text.class);
		j9.setMapOutputValueClass(Text.class);			
		FileInputFormat.addInputPath(j9,new Path(args[0]));
		FileOutputFormat.setOutputPath(j9, new Path(args[1]));			

		DistributedCache.addCacheFile(new URI("/cus.dat"),j9.getConfiguration());


		System.exit(j9.waitForCompletion(true)?0:1);
		
			break;
			default:
				System.out.println("Pls enter choice between 1 to 9");
				break;
	}
	}
		catch(InputMismatchException e)
		{
			System.out.println("pls enter whole number");
		}
}}
